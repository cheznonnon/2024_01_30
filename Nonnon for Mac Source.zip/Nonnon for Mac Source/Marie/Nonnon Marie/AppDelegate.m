//
//  AppDelegate.m
//  Nonnon Marie
//
//  Created by nonnon on 2022/07/05.
//

#import "AppDelegate.h"


#import "../../nonnon/neutral/posix.c"

#import "../../nonnon/neutral/bmp/all.c"
#import "../../nonnon/neutral/curico.c"
#import "../../nonnon/neutral/jpg.c"
#import "../../nonnon/neutral/png.c"

#import "../../nonnon/win32/gdi.c"

#import "../../nonnon/mac/image.c"
#import "../../nonnon/mac/n_imgbox.c"
#import "../../nonnon/mac/window.c"

// [x] : sandbox off is needed
//#import "../../nonnon/project/ini2gdi.c"


#include "stub.c"




void
n_marie_maxsize( NSWindow *window, CGFloat *sx, CGFloat *sy )
{

	CGFloat max_ratio = 1.0;


	CGFloat max_sx = NSWidth ( [ [window screen] visibleFrame ] ) * max_ratio;
	CGFloat max_sy = NSHeight( [ [window screen] visibleFrame ] ) * max_ratio;

	if ( sx != NULL ) { (*sx) = max_sx; } 
	if ( sy != NULL ) { (*sy) = max_sy; } 


	return;
}




#define N_MARIE_ROTATE_U ( 0 )
#define N_MARIE_ROTATE_L ( 1 )
#define N_MARIE_ROTATE_D ( 2 )
#define N_MARIE_ROTATE_R ( 3 )




@interface AppDelegate () <NonnonDragAndDrop_delegate>

@property (strong) IBOutlet NSWindow *window;

@property (strong) IBOutlet NonnonStub *n_stub;

@property (weak) IBOutlet NonnonImgbox *n_imgbox;

@property (strong) IBOutlet NSImageView *n_image_view;

@end


@implementation AppDelegate {

	NSString     *n_path;
	n_bmp         n_bmp_drop_here;
	n_bmp         n_bmp;
	n_bmp         n_bmp_processed;
	n_bmp         n_bmp_clip;
	n_posix_bool  n_error;
	n_posix_bool  n_resample_onoff;
	int           n_rotate;
	CGPoint       pt;
	CGFloat       n_ox;
	CGFloat       n_oy;
	BOOL          n_scrollbar_draw_stop;

}




- (void) n_load
{

	_n_image_view.hidden = TRUE;


	n_posix_char *path = n_mac_nsstring2str( n_path );
//NSLog( @"%s", path );

	if ( n_posix_stat_is_dir( path ) )
	{
		n_string_free( path );

		n_error = n_posix_true;
		return;
	}

	n_curico curico; n_curico_zero( &curico );

	if (
		( n_png_png2bmp( path, &n_bmp ) )
		&&
		( n_jpg_jpg2bmp( path, &n_bmp ) )
		&&
		( n_curico_load( &curico, &n_bmp, path ) )
		&&
		( n_bmp_load( &n_bmp, path ) )
		//&&
		//( n_ini2gdi_load( path, &n_bmp ) )
		&&
		( n_mac_image_load( path, &n_bmp ) )
	)
	{
		n_error = n_posix_true;
	} else {
		n_error = n_posix_false;

		n_bmp_mac( &n_bmp );

//NSLog( @"%s : %d", path, n_string_path_ext_is_same( ".gif", path ) );
		if ( n_string_path_ext_is_same( ".gif", path ) )
		{

			// [!] : special mode for animation GIFs

			_n_image_view.hidden = FALSE;


			NSImage *img = [[NSImage alloc] initWithContentsOfFile:n_path];

			NSRect rect = { { 0,0 }, img.size };
			[_n_image_view setFrame:rect];

			[[_window contentView] addSubview:_n_image_view];
			[_n_image_view setTarget:self];

			[_n_image_view setImage:img];
			_n_image_view.animates = TRUE;


			// [Needed] : DnD will be disabled

			[_n_stub setFrame:[[NSScreen mainScreen] frame]];
			[[_window contentView] addSubview:_n_stub];

			_n_stub.delegate = self;

		}

	}

	n_string_free( path );

}

- (void) n_prepare_bitmap
{

	const n_type_gfx min_size  = 256;


//NSLog( @"%d", n_error );
	n_bmp_free( &n_bmp_processed );
	if ( n_error )
	{
		n_bmp_carboncopy( &n_bmp_drop_here, &n_bmp_processed );
	} else {
		n_bmp_carboncopy( &n_bmp          , &n_bmp_processed );
	}

	if ( n_rotate == N_MARIE_ROTATE_U )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_R )
	{
		n_bmp_rotate( &n_bmp_processed, N_BMP_ROTATE_LEFT );
	} else
	if ( n_rotate == N_MARIE_ROTATE_D )
	{
		n_bmp_flush_mirror( &n_bmp_processed, N_BMP_MIRROR_UPSIDE_DOWN );
	} else
	if ( n_rotate == N_MARIE_ROTATE_L )
	{
		n_bmp_rotate( &n_bmp_processed, N_BMP_ROTATE_RIGHT );
	}

	CGFloat isx = N_BMP_SX( &n_bmp_processed );
	CGFloat isy = N_BMP_SY( &n_bmp_processed );

	CGFloat max_sx, max_sy; n_marie_maxsize( _window, &max_sx, &max_sy );

	if ( n_resample_onoff )
	{

		double ratio_x = 1.0;
		double ratio_y = 1.0;

		if ( max_sx < isx )
		{
			ratio_x = max_sx / isx;
		}

		if ( max_sy < isy )
		{
			ratio_y = max_sy / isy;
		}

		n_type_real ratio = n_posix_min_n_type_real( ratio_x, ratio_y );

		n_bmp_resampler( &n_bmp_processed, ratio, ratio );

	}

	if ( _n_image_view.hidden )
	{
		n_type_gfx rsx = n_posix_max_n_type_gfx( min_size, N_BMP_SX( &n_bmp_processed ) );
		n_type_gfx rsy = n_posix_max_n_type_gfx( min_size, N_BMP_SY( &n_bmp_processed ) );

		n_bmp_resizer( &n_bmp_processed, rsx, rsy, n_bmp_black, N_BMP_RESIZER_CENTER );
	}


	n_ox = 0;
	n_oy = 0;

	if ( n_rotate == N_MARIE_ROTATE_U )
	{
//NSLog( @"%d %f", N_BMP_SY( &n_bmp_processed ), max_sy );
		if ( N_BMP_SY( &n_bmp_processed ) > max_sy )
		{
			n_oy = N_BMP_SY( &n_bmp_processed ) - max_sy;
		}
	} else
	if ( n_rotate == N_MARIE_ROTATE_R )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_D )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_L )
	{
		//
	}

	n_scrollbar_draw_stop = TRUE;

}

- (void) n_draw
{

	//const n_type_gfx min_size  = 256;

	CGFloat img_sx = N_BMP_SX( &n_bmp_processed );
	CGFloat img_sy = N_BMP_SY( &n_bmp_processed );

	CGFloat max_sx, max_sy; n_marie_maxsize( _window, &max_sx, &max_sy );

	CGFloat csx = n_posix_min_n_type_real( max_sx, img_sx );
	CGFloat csy = n_posix_min_n_type_real( max_sy, img_sy );

	[_window setContentSize:NSMakeSize( csx,csy )];
	[_n_imgbox setFrame:NSMakeRect( 0,0,csx,csy )];

	if ( ( img_sx > max_sx )||( img_sy > max_sy ) )
	{

		n_type_gfx sx = n_posix_min_n_type_gfx( img_sx, max_sx );
		n_type_gfx sy = n_posix_min_n_type_gfx( img_sy, max_sy );

		n_bmp_new( &n_bmp_clip, sx, sy );
		n_bmp_fastcopy( &n_bmp_processed, &n_bmp_clip, n_ox,n_oy,sx,sy, 0,0 );

		_n_imgbox.n_bmp_data = &n_bmp_clip;


		// [!] : Fake Scroller
		
		const CGFloat scroller_size = 12;


		{ // [!] : Fake Scroller : Horizontal

		NSRect scroller_x_rect_shaft;
		NSRect scroller_x_rect_thumb;

		CGFloat items_per_canvas = csx;
		CGFloat max_count        = img_sx;
//NSLog( @"%f %f", items_per_canvas, max_count );

		if (
			( n_scrollbar_draw_stop == FALSE )
			&&
			( trunc( items_per_canvas ) < max_count )
		)
		{

			CGFloat shaft = csx - scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsy = scroller_size;
			CGFloat scrsx = n_posix_max_n_type_real( scroller_size, ( items_per_canvas / page ) - scroller_size );
			CGFloat scr_y = csy - scrsy;
			CGFloat scr_x = ( n_ox / max_count ) * items_per_canvas;
//NSLog( @"%f %f", scr_y, n_oy );


			// [!] : for hit test

			scroller_x_rect_shaft = NSMakeRect(     0, scr_y, shaft, scrsy );
			scroller_x_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			// [!] : shaft

			n_bmp_flip_onoff = n_posix_true;

			n_bmp bmp_scroll; n_bmp_zero( &bmp_scroll );

			{
				//n_type_gfx  x = scroller_x_rect_shaft.origin.x;
				//n_type_gfx  y = scroller_x_rect_shaft.origin.y;
				n_type_gfx sx = scroller_x_rect_shaft.size.width;
				n_type_gfx sy = scroller_x_rect_shaft.size.height;

				u32 color_shaft = n_bmp_argb_mac( 64, 128,128,128 );

				n_bmp_new_fast( &bmp_scroll, sx,sy );
				n_bmp_flush( &bmp_scroll, n_bmp_white_invisible );

				n_bmp_roundrect( &bmp_scroll, 0,0,sx,sy, color_shaft, 50 );
			}


			// [!] : thumb / knob

			//if(0)
			{
				n_type_gfx  x = scroller_x_rect_thumb.origin.x;
				//n_type_gfx  y = scroller_x_rect_thumb.origin.y;
				n_type_gfx sx = scroller_x_rect_thumb.size.width;
				n_type_gfx sy = scroller_x_rect_thumb.size.height;

				u32 color_thumb = n_bmp_argb_mac( 192, 128,128,128 );
				n_bmp_roundrect( &bmp_scroll, x,0,sx,sy, color_thumb, 50 );
			}

			{
				n_type_gfx  x = scroller_x_rect_shaft.origin.x;
				n_type_gfx  y = scroller_x_rect_shaft.origin.y;
				n_type_gfx sx = scroller_x_rect_shaft.size.width;
				n_type_gfx sy = scroller_x_rect_shaft.size.height;

				n_bmp_transcopy( &bmp_scroll, &n_bmp_clip, 0,0,sx,sy, x,y );
			}

			n_bmp_flip_onoff = n_posix_false;

			n_bmp_free_fast( &bmp_scroll );

		}

		} // [!] : Fake Scroller : Horizontal


		{ // [!] : Fake Scroller : Vertical

		NSRect scroller_y_rect_shaft;
		NSRect scroller_y_rect_thumb;

		CGFloat items_per_canvas = csy;
		CGFloat max_count        = img_sy;
//NSLog( @"%f %f", items_per_canvas, max_count );

		if (
			( n_scrollbar_draw_stop == FALSE )
			&&
			( trunc( items_per_canvas ) < max_count )
		)
		{

			CGFloat shaft = csy - scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = scroller_size;
			CGFloat scrsy = n_posix_max_n_type_real( scroller_size, ( items_per_canvas / page ) - scroller_size );
			CGFloat scr_x = csx - scrsx;
			CGFloat scr_y = ( ( ( max_count - items_per_canvas ) - n_oy ) / max_count ) * items_per_canvas;
//NSLog( @"%f %f", scr_y, n_oy );


			// [!] : for hit test

			scroller_y_rect_shaft = NSMakeRect( scr_x,     0, scrsx, shaft );
			scroller_y_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			// [!] : shaft

			n_bmp_flip_onoff = n_posix_true;

			n_bmp bmp_scroll; n_bmp_zero( &bmp_scroll );

			{
				//n_type_gfx  x = scroller_y_rect_shaft.origin.x;
				//n_type_gfx  y = scroller_y_rect_shaft.origin.y;
				n_type_gfx sx = scroller_y_rect_shaft.size.width;
				n_type_gfx sy = scroller_y_rect_shaft.size.height;

				u32 color_shaft = n_bmp_argb_mac( 64, 128,128,128 );

				n_bmp_new_fast( &bmp_scroll, sx,sy );
				n_bmp_flush( &bmp_scroll, n_bmp_white_invisible );

				n_bmp_roundrect( &bmp_scroll, 0,0,sx,sy, color_shaft, 50 );
			}


			// [!] : thumb / knob

			//if(0)
			{
				//n_type_gfx  x = scroller_y_rect_thumb.origin.x;
				n_type_gfx  y = scroller_y_rect_thumb.origin.y;
				n_type_gfx sx = scroller_y_rect_thumb.size.width;
				n_type_gfx sy = scroller_y_rect_thumb.size.height;

				u32 color_thumb = n_bmp_argb_mac( 222, 128,128,128 );
				n_bmp_roundrect( &bmp_scroll, 0,y,sx,sy, color_thumb, 50 );
			}

			{
				n_type_gfx  x = scroller_y_rect_shaft.origin.x;
				n_type_gfx  y = scroller_y_rect_shaft.origin.y;
				n_type_gfx sx = scroller_y_rect_shaft.size.width;
				n_type_gfx sy = scroller_y_rect_shaft.size.height;

				n_bmp_transcopy( &bmp_scroll, &n_bmp_clip, 0,0,sx,sy, x,y );
			}

			n_bmp_flip_onoff = n_posix_false;

			n_bmp_free_fast( &bmp_scroll );

		}

		} // [!] : Fake Scroller : Vertical

	} else {

		_n_imgbox.n_bmp_data = &n_bmp_processed;

	}

	[_n_imgbox display];

	n_mac_window_centering( _window );

}

- (void) n_window_init
{

	_n_imgbox.delegate = self;

	[self n_prepare_bitmap];
	[self n_draw];

	n_mac_window_centering( _window );

	n_mac_window_show( _window );

}




- (BOOL)application:(NSApplication *)sender
           openFile:(NSString *)filename
{

	NSString *path = n_mac_alias_resolve( filename );

	[self NonnonDragAndDrop_dropped:path];
	[self n_window_init];

	return YES;
}

- (void) NonnonDragAndDrop_dropped:(NSString*)nsstr; {
    
//NSLog( @"dropped : %@", nsstr );

	NSString *path = n_mac_alias_resolve( nsstr );
//NSLog( @"resolved : %@", path );

	n_path = [path copy];

	[self n_load];
	if ( n_error ) { [self n_marie_drophere]; }
	[self n_prepare_bitmap];
	[self n_draw];

	n_mac_foreground();

}


- (void) n_marie_drophere
{

	n_error = n_posix_true;


	u32 accent = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor] ) );

	u32 bg;
	if ( n_mac_is_darkmode() )
	{
		bg = n_bmp_black;
	} else {
		bg = n_bmp_white;
	}

	n_bmp_new( &n_bmp_drop_here, 256,256 );
	n_bmp_flush_gradient( &n_bmp_drop_here, bg, accent, N_BMP_GRADIENT_VERTICAL );

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:@"manekineko_1" ofType:@"png"];
//NSLog( @"%@", path );
//NSLog( @"%s", n_mac_nsstring2str( path ) );

	n_bmp neko; n_bmp_zero( &neko );
	n_png_png2bmp( n_mac_nsstring2str( path ), &neko );
	n_bmp_mac( &neko );
	n_bmp_blendcopy( &neko, &n_bmp_drop_here, 0,0,256,256, 0,0, 0.5 );
	n_bmp_free( &neko );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = 256;
	gdi.sy                  = 256;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_argb( 0,255,255,255 );
	gdi.base_color_fg       = n_bmp_argb( 0,255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = n_posix_literal( "Drop Here" );
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = 33;
	gdi.text_style          = N_GDI_TEXT_SINK;
	gdi.text_color_main     = n_bmp_rgb( 255,255,255 );
	gdi.text_color_sink_tl  = n_bmp_argb( 128, 10, 10, 10 );
	gdi.text_color_sink_br  = n_bmp_argb( 128,255,255,255 );
	gdi.text_fxsize1        = 1;
	gdi.text_fxsize2        = 1;

	n_bmp bmp_text; n_bmp_zero( &bmp_text );

	n_bmp_flip_onoff = n_posix_true;
	n_gdi_bmp( &gdi, &bmp_text );
	n_bmp_flip_onoff = n_posix_false;

	n_bmp_flush_transcopy( &bmp_text, &n_bmp_drop_here );

	n_bmp_free_fast( &bmp_text );


	return;
}




- (IBAction)n_marie_menu_onoff:(id)sender {

	if ( n_resample_onoff )
	{
		n_resample_onoff = n_posix_false;
		[sender setState:NSControlStateValueOff];
	} else {
		n_resample_onoff = n_posix_true;
		[sender setState:NSControlStateValueOn];
	}

	[self n_prepare_bitmap];
	[self n_draw];

}




- (void)awakeFromNib
{

	n_bmp_zero( &n_bmp_drop_here );
	n_bmp_zero( &n_bmp           );
	n_bmp_zero( &n_bmp_processed );
	n_bmp_zero( &n_bmp_clip      );

	n_resample_onoff = n_posix_true;


	n_mac_image_window = _window;


	_n_image_view = [[NSImageView alloc] init];
	_n_stub       = [[NonnonStub  alloc] init];


	_n_image_view.hidden = TRUE;


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	// [!] : accent color
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( accentColorChanged: )
		       name: @"AppleColorPreferencesChangedNotification"
		     object: nil
	];

	// [!] : dark mode
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( darkModeChanged: )
		       name: @"AppleInterfaceThemeChangedNotification"
		     object: nil
	];

}

- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	if ( n_error )
	{
		[self n_marie_drophere];
		[self n_prepare_bitmap];
		[_n_imgbox display];
	}

}

- (void) darkModeChanged:(NSNotification *)notification
{
//NSLog( @"darkModeChanged" );

	if ( n_error )
	{
		[self n_marie_drophere];
		[self n_prepare_bitmap];
		[_n_imgbox display];
	}

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {

	n_mac_window_hide( _window );

}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application

	if ( NULL == N_BMP_PTR( &n_bmp ) )
	{
		[self n_marie_drophere];
		[self n_window_init];
	}

}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (IBAction)n_marie_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"marie" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




- (void) keyDown:(NSEvent*)event
{
//NSLog( @"%d", event.keyCode );


	if ( _n_image_view.hidden == FALSE )
	{
		n_rotate = N_MARIE_ROTATE_U;
		return;
	}


	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_LEFT:

		if ( n_rotate == N_MARIE_ROTATE_U )
		{
			n_rotate = N_MARIE_ROTATE_L;
		} else
		if ( n_rotate == N_MARIE_ROTATE_L )
		{
			n_rotate = N_MARIE_ROTATE_D;
		} else
		if ( n_rotate == N_MARIE_ROTATE_D )
		{
			n_rotate = N_MARIE_ROTATE_R;
		} else
		if ( n_rotate == N_MARIE_ROTATE_R )
		{
			n_rotate = N_MARIE_ROTATE_U;
		}
//NSLog( @"L : %d", n_rotate );

		[self n_prepare_bitmap];
		[self n_draw];

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		if ( n_rotate == N_MARIE_ROTATE_U )
		{
			n_rotate = N_MARIE_ROTATE_R;
		} else
		if ( n_rotate == N_MARIE_ROTATE_R )
		{
			n_rotate = N_MARIE_ROTATE_D;
		} else
		if ( n_rotate == N_MARIE_ROTATE_D )
		{
			n_rotate = N_MARIE_ROTATE_L;
		} else
		if ( n_rotate == N_MARIE_ROTATE_L )
		{
			n_rotate = N_MARIE_ROTATE_U;
		}
//NSLog( @"R : %d", n_rotate );

		[self n_prepare_bitmap];
		[self n_draw];

	break;

	} // switch

}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( n_resample_onoff ) { return; }


	pt = [theEvent locationInWindow];

}

- (void) mouseUp:(NSEvent*) theEvent
{

	// [x] : rightMouseDown/Up is never called

	if ( [theEvent clickCount] == 2 )
	{

		n_mac_window_centering( _window );

	}

	if ( n_resample_onoff )
	{
		//
	} else {
		n_scrollbar_draw_stop = TRUE;
		[self n_draw];
	}

	[[NSCursor arrowCursor] set];

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");

	if ( n_resample_onoff ) { return; }


	[[NSCursor closedHandCursor] set];


	CGPoint pt_cur = [theEvent locationInWindow];

	CGFloat dx = pt.x - pt_cur.x;
	CGFloat dy = pt.y - pt_cur.y;

	pt = pt_cur;


	n_ox += dx;
	n_oy += dy;

	if ( n_ox < 0 ) { n_ox = 0; }
	if ( n_oy < 0 ) { n_oy = 0; }

	CGFloat msx = N_BMP_SX( &n_bmp_processed ) - NSWidth ( [_n_imgbox frame] );
	CGFloat msy = N_BMP_SY( &n_bmp_processed ) - NSHeight( [_n_imgbox frame] );

	if ( n_ox > msx ) { n_ox = msx; }
	if ( n_oy > msy ) { n_oy = msy; }


	n_scrollbar_draw_stop = FALSE;
	[self n_draw];

}


@end
