//
//  AppDelegate.h
//  hunyapiyo3
//
//  Created by のんのん on 2022/07/14.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

